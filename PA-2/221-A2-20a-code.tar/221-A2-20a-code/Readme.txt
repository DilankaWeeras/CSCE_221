Dilanka Weerasinghe
126007816
CSCE 221 501

I certify that I have listed all the sources that I used to develop the solutions and code to the
submitted work.

On my honor as an Aggie, I have neither given nor received any unauthorized help
on this academic work.


Dilanka Weerasinghe -- 2/5/2020

This readme is applicable for both the DDL and the templated DLL

There were no errors with the code.

This is code for a double linked list. It starts with a node for head and tail and can add nodes imbetween. It is like an array but resizing and other functionality will take less steps
and save memory. My first plan of attack for the exceptions was to use exit(), I recently began to learn c code in ecen 449 and instead of using exeption handleing with throws I instead decided 
to use the exit() function with a cout for failure. This was not used in the end as I ended up using try catch throws to handle the errors I thought could occor. These errors being whenever the linked list is empty
or whenever there is a removal in a different list. For reference I asked some of the people at my lab table about linked lists because in my 121 class we only did a single linked list, 
not a double and it only used a pointer instead of a node for head and tail. Once I got my head around the basics again, the rest of the assignment was easy. I ran into trouble in templating 
the constructor and the Node constructor but the fix was just adding an object instead of an int for default.

The program was tested with the testbench provided with some added test placed in my me. These new tests were selected because they were not a part of the testbench already and they were required by 
the readme constraints.

For the Templated DLL te only things changed was an addition of templating to the Node class and the list class. The only typename used was Object instead of the int from the normal DLL. As stated before
the only part that gave me trouble was the constructor for the DLL and the Node but that was solved by making it an object instead of an int. This was somthing I overlooked before compiling my code.

