Dilanka Weerasinghe
126007816
CSCE 221 501

I certify that I have listed all the sources that I used to develop the solutions and code to the
submitted work.

On my honor as an Aggie, I have neither given nor received any unauthorized help
on this academic work.


Dilanka Weerasinghe -- 2/5/2020

1)
This problem was to make a queue utilizing the Templated DLL that we made previously

2)
There were no abstract datatypes used in this section of the code but the previous section used a DLL.
This made a list out of nodes that used pointers to show the next object in the list.
There were no algoritms. The most complex part of the assignment was to navigate through the list to 
find a minimum value.

The running time of the functions were all O(1) for the 4 or 5 functions in the program except for one.
The min function needs to travese the List so it has a O(n).

3)
The classes used here were a struct for a Node a Templated Class for the Double Linked list and
another class for the MinQueue. The MinQueue used the DLL as a way to push and pop the data.

4) - Code Given
5) - Code Given

6)
The program has try catch exeptions for trying to delete the head or tail or also if the list is empty.
I used the default try catch statement from vsCode and it will list the const *char problem and abort the program.

7)
A tester file was made for the minQ that will test the queue with strings and ints.
Error checking occors and checks for abortion from the program. It occored at the correct moments. Like when Poping too many times.


