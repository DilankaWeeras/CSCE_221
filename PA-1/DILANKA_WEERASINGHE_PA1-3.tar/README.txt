Dilanka Weerasinghe
126007816
CSCE 221 501

I certify that I have listed all the sources that I used to develop the solutions and code to the
submitted work.

On my honor as an Aggie, I have neither given nor received any unauthorized help
on this academic work.


Dilanka Weerasinghe -- 2/5/2020

There were no errors with the code. 

All the Collection class function work as advertised and extra helper functions exist in stress ball and collection to assist comparasins
and addig size to the array.

I tested my program for correctness with some try catch and a collection test file that displayed elements of the functions at work.

Dilanka Weerasinghe -- 2/16/2020 PA3

I do not know if my code works completly.
I have never worked with templates before but I watched a tutorial on template class and I better understood what is going on.
Althought the file for Collection_template has not been tested yet I belive it will work because I follow the logic correctly and but I don't really 
know how my code is effected by this template.

It said we could make the Jeans have whatever colors and sizes we wanted so I kept it the same. Easier to use test with the same data.

I have trouble making makefiles.

Look, I really don't like this. I have never worked with template before and the TA's said this would be extremly easy. I am almost 100% sure My code is 99.99% 
right (definintly not true). I must be missing one thing. I don't really know how the linker operates with only having an .h file. I wish there was time for this during lab because no one would
prioritize a assignment due sunday over a test. I had 3 labs due this week and 2 tests and I directed a hackathon this weekend. There was no way I was getting this done.

Please actually read my code. I know Its close. Also I have an interview during lab monday so I wont be able to stay the whole time but I do want yall to teach
me how to finish this code.

Thanks

Update, it was not close!!!!
I fixed most of the major mustakes on my own. Landon and Joseph 
helped me learn a lo about templates and a little with the debugging. Although I finished I still had to write most of the code from the top.
This helped me fix the errors that I was unable to see without seeing just a finished product.

Questions:

Write about generic programing based on this assignment.

Generic programing is extremly useful for so many applications. Instead of having to repeat code over and over again
you instead only need to write one piece of code to adapt to all datatypes or classes. Essencially it increases the 
usability and efficiency of the code. If you want to perform very similar tasks on many classes why would you need to rewrite the code again.
I am confused on some aspect of templating though. I read online that a template recreates a source file at compile time so really it doesn't
save any time besides the actual coder. But just because it doesn't actually save any compute time doesn't mean it isn't as important as it is.
Here we use it to perform operations on two classes that are Essencially the same. In our case it works very well.
