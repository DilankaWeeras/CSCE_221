Dilanka Weerasinghe
126007816
CSCE 221 501

I certify that I have listed all the sources that I used to develop the solutions and code to the
submitted work.

On my honor as an Aggie, I have neither given nor received any unauthorized help
on this academic work.


Dilanka Weerasinghe -- 2/5/2020

There were no errors with the code. 

All the Collection class function work as advertised and extra helper functions exist in stress ball and collection to assist comparasins
and addig size to the array.

I tested my program for correctness with some try catch and a collection test file that displayed elements of the functions at work.

