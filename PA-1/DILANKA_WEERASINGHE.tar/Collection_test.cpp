//Collection test

#include <iostream>
#include <fstream>
#include <cstdlib>
#include "Collection.h"
//#include "time.h"


main()
{
    Collection balls;
    balls.insert_item(Stress_ball());
    balls.insert_item(Stress_ball());
    balls.insert_item(Stress_ball());
    balls.insert_item(Stress_ball());
    balls.insert_item(Stress_ball());
    balls.insert_item(Stress_ball());

    Stress_ball test1 = Stress_ball(red, medium);

    balls.insert_item(test1);
    
    std::cout << balls.contains(test1) << std::endl;
    std::cout << "Total: " << balls.total_items() << std::endl << "Total Red: " <<  balls.total_items(red) << std::endl << "Total Medium" << balls.total_items(medium) << std::endl << std::endl;
    balls.print_items();
    std::cout << std::endl;
    balls.remove_any_item();
    std::cout << std::endl;
    balls.print_items();
    std::cout << std::endl;
    balls.remove_this_item(test1);

    sort_by_size(balls, Sort_choice::bubble_sort);
    //sort_by_size(balls, Sort_choice::insertion_sort);
    //sort_by_size(balls, Sort_choice::selection_sort);

    std::cout << balls;
    
    std::ifstream in;
    in.open("stress_ball1.data");
    if(!in.is_open()) {std::cout << "Could not open file\n\n";}

    Collection balls2;
    in >> balls2;

    in.close();

    Collection balls3 = balls2;
    std::cout << balls3 << std::endl;

    sort_by_size(balls3, Sort_choice::bubble_sort);
    std::cout << balls3 << std::endl;

    std::cout << balls2 << std::endl;

    sort_by_size(balls2, Sort_choice::insertion_sort);
    std::cout << balls2 << std::endl;

    in.open("stress_ball2.data");

    Collection balls4;

    in >> balls4;

    in.close();
    
    std::cout << balls4 << std::endl;
    sort_by_size(balls4, Sort_choice::selection_sort);
    std::cout << balls4 << std::endl;

    Collection balls5;
    
    balls5 = make_union(balls2, balls4);
    
    std::ofstream out;
    out.open("stress_ball3.data");
    
    std::cout << balls5 << std::endl;

    out << balls5;
    out.close();

    swap(balls5, balls4);

    std::cout << balls5 << std::endl << balls4;


}

/* STUFF THAT DOESN'T WORK

-selection sort
-instream

*/